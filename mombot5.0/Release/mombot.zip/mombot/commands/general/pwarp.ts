	gosub :BOT~loadVars

	setVar $BOT~help[1]  $BOT~tab&"pwarp {sector:#} {"&#34&"trader_name"&#34&"} "
	setVar $BOT~help[2]  $BOT~tab&"      "
	setVar $BOT~help[3]  $BOT~tab&"        planet warps to sector "
	setVar $BOT~help[4]  $BOT~tab&"      "
	setVar $BOT~help[5]  $BOT~tab&"    Options: "
	setVar $BOT~help[6]  $BOT~tab&"           {sector:#} - sector to pwarp to "
	setVar $BOT~help[7]  $BOT~tab&"      {"&#34&"trader_name"&#34&"} - trader to pwarp to"
	setVar $BOT~help[8]  $BOT~tab&"         "
	setVar $BOT~help[9]  $BOT~tab&"    Examples:"
	setVar $BOT~help[10] $BOT~tab&"               >p 233 - normal pwarp"
	setVar $BOT~help[11] $BOT~tab&"         >p planet 12 - pwarp to last known "
	setVar $BOT~help[12] $BOT~tab&"                        location of planet 12 "
	setVar $BOT~help[13] $BOT~tab&"              >p mind - pwarp to a corp member with mind"
	setVar $BOT~help[14] $BOT~tab&"                        in their name"
	setVar $BOT~help[15] $BOT~tab&"     >p "&#34&"mind dagger"&#34&" - pwarp to corp member"
	gosub :bot~helpfile

	killalltriggers
	setvar $player~save true
	if ($bot~parm1 <> $PLAYER~CURRENT_SECTOR)
		gosub  :player~currentPrompt
	else
		gosub :PLAYER~quikstats
	end
	setVar $PLAYER~startingLocation $PLAYER~CURRENT_PROMPT
	setVar $bot~validPrompts "Citadel"
	gosub :bot~checkstartingprompt

	gosub :player~checkfortravelname

	isNumber $test $bot~parm1
	if (($test = FALSE) OR ($bot~parm1 = ""))
		setVar $SWITCHBOARD~message "Sector must be entered as a number between 11-"&SECTORS&"*"
		gosub :SWITCHBOARD~switchboard
		goto :wait_for_command
	else    
		if (($bot~parm1 > SECTORS) OR ($bot~parm1 < 11))    
			setVar $SWITCHBOARD~message "Sector must be entered as a number between 11-"&SECTORS&"*"  
			gosub :SWITCHBOARD~switchboard
			goto :wait_for_command
		else
			setVar $PLANET~warpto $bot~parm1
			if ($PLAYER~CURRENT_SECTOR = $PLANET~warpto)
				setVar $SWITCHBOARD~message "Already in that sector!*"
				gosub :SWITCHBOARD~switchboard
				goto :wait_for_command
			end
		end
	end
	
		getWordPos " "&$bot~user_command_line&" " $pos " scan "
		if ($pos > 0)
			setVar $PLANET~PWARP_SCAN TRUE
		else
			setVar $PLANET~PWARP_SCAN FALSE
		end

		gosub :planet~pwarp
	halt

# includes:
include "source\include\bot"
