:emx
:reset
	disconnect
